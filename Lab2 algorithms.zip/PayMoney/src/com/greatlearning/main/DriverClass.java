package com.greatlearning.main;

import java.util.Scanner;

public class DriverClass {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the size of transaction array");

		int size = sc.nextInt();

		int[] transaction_array = new int[size];
		System.out.println("Enter the values of array");

		for (int i = 0; i < size; i++) {

			transaction_array[i] = sc.nextInt();
		}
		System.out.println("Please enter the total number of targets that needs to be achieved : ");

		int numOfTargetNeedsToCheck = sc.nextInt();

		while (numOfTargetNeedsToCheck-- != 0) {

			System.out.println("Enter the value of target");
			long target = sc.nextInt();
			long transaction_target = 0;
			boolean flag = false;

			for (int i = 0; i < size; i++) {

				transaction_target = transaction_target + transaction_array[i];
				if (transaction_target >= target) {
					flag = true;
					System.out.println("Target achieved after " + ++i + " transactions");
					break;
				}

			}

			if (!flag) {
				System.out.println("Given target is not achieved");
			}

		}
		sc.close();
	}

}
